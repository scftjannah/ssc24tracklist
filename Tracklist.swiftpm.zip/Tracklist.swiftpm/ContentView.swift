import SwiftUI

struct ContentView: View {
    @AppStorage("_shouldShowOnboarding") var shouldShowOnboarding: Bool = true
    @State var selectedTab = 1
    
    var body: some View {
        TabView {
            AlbumView()
                .tabItem {
                    Label("Songs", systemImage: "music.mic")
                }
                .tag(1)
                .fullScreenCover(isPresented: $shouldShowOnboarding, content: {
                    OnboardingView(shouldShowOnboarding: $shouldShowOnboarding)
                })
            
            ChartView()
                .tabItem {
                    Label("Charts", systemImage: "chart.bar.xaxis")
                }
                .tag(2)
        }
        .tableColumnHeaders(.hidden)
    }
}
