import SwiftUI
import SwiftData

@main
struct TacklistApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
                .modelContainer(for: Songs.self)
                .preferredColorScheme(.dark)
        }
    }
}
