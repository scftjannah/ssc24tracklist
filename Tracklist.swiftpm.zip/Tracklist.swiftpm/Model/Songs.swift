import SwiftData

@Model
class Songs {
    var name: String
    var artist: String
    var genre: String
    var review: String
    var rating: Int
    var isCompleted: Bool
    
    init(name: String, artist: String, genre: String, review: String, rating: Int, isCompleted: Bool) {
        self.name = name
        self.artist = artist
        self.genre = genre
        self.review = review
        self.rating = rating
        self.isCompleted = isCompleted
    }
}
