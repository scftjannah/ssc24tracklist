import SwiftUI

struct OnboardingView: View {
    @Environment(\.dismiss) var dismiss
    
    @Binding var shouldShowOnboarding: Bool
    @State var opacity = 0.0
    
    
    let purpleCustom = Color(red: 0.20, green: 0.09, blue: 0.30, opacity: 1.00)
    let blueCustom = Color(red: 0.10, green: 0.14, blue: 0.28, opacity: 1.00)
    
    var body: some View {
        let bgGradient = LinearGradient(colors: [.clear, purpleCustom], startPoint: .topLeading, endPoint: .bottomTrailing)
        
        NavigationStack {
            VStack(alignment: .center) {
                
                VStack(alignment: .center) {
                    Image("appIcon")
                        .resizable()
                        .frame(width: 75, height: 75)
                        .foregroundStyle(.pink)
                        .clipShape(RoundedRectangle(cornerRadius: 15))
                        .accessibilityRemoveTraits(.isImage)
                        .accessibilityLabel("Tracklist app icon")
                    
                    Text("Welcome to Tracklist!")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .accessibilityAddTraits(.isHeader)
                }
                .padding()
                .opacity(opacity)
                .animate {
                    opacity = 1.0
                }
                
                
                VStack(alignment: .leading) {
                    
                    VStack(alignment: .leading) {
                        HStack {
                            Image(systemName: "star.fill")
                                .resizable()
                                .frame(width: 50, height: 50)
                                .foregroundStyle(.yellow)
                                .shadow(color: .yellow.opacity(0.25), radius: 2, x: 0, y: 4)
                                .shadow(color: .yellow.opacity(0.25), radius: 2, x: 0, y: 4)
                                .accessibilityRemoveTraits(.isImage)
                                .accessibilityLabel("Star")
                            
                            VStack(alignment: .leading) {
                                Text("List and Rate!")
                                    .font(.title)
                                    .fontWeight(.medium)
                                Text("All of your favorite music ratings never been more easier.")
                                    .font(.headline)
                                    .fontWeight(.medium)
                            }
                            .padding()
                        }
                    }
                    .padding()
                    .opacity(opacity)
                    .animate {
                        opacity = 1.0
                    }
                    
                    
                    VStack {
                        HStack {
                            Image(systemName: "pencil.line")
                                .resizable()
                                .frame(width: 50, height: 50)
                                .foregroundStyle(.blue)
                                .shadow(color: .blue.opacity(0.25), radius: 2, x: 0, y: 4)
                                .shadow(color: .blue.opacity(0.25), radius: 2, x: 0, y: 4)
                                .accessibilityRemoveTraits(.isImage)
                                .accessibilityLabel("Pencil with a line")
                            
                            VStack(alignment: .leading) {
                                Text("Jot Some Reviews...")
                                    .font(.title)
                                    .fontWeight(.medium)
                                    .accessibilityLabel("Jot some reviews")
                                
                                Text("What do you think about the music, is it really enough to give it 5 stars?")
                                    .font(.headline)
                                    .fontWeight(.medium)
                            }
                            .padding()
                        }
                    }
                    .padding()
                    .opacity(opacity)
                    .animate {
                        opacity = 1.0
                    }
                    
                    VStack {
                        HStack {
                            Image(systemName: "chart.bar.xaxis")
                                .resizable()
                                .frame(width: 50, height: 50)
                                .foregroundStyle(.green)
                                .shadow(color: .green.opacity(0.25), radius: 2, x: 0, y: 4)
                                .shadow(color: .green.opacity(0.25), radius: 2, x: 0, y: 4)
                                .accessibilityRemoveTraits(.isImage)
                                .accessibilityLabel("Chart bar")
                            
                            VStack(alignment: .leading) {
                                Text("Charts for Music")
                                    .font(.title)
                                    .fontWeight(.medium)
                                
                                Text("What kind of rating you give, what kind of artist you listen the most... easily checked by charts!")
                                    .font(.headline)
                                    .fontWeight(.medium)
                                    .accessibilityLabel("What kind of rating you give, what kind of artist you listen the most, easily checked by charts!")
                            }
                            .padding()
                        }
                    }
                    .padding()
                    
                    .opacity(opacity)
                    .animate {
                        opacity = 1.0
                    }
                }
                
                Button {
                    dismiss()
                    shouldShowOnboarding = false
                } label: {
                    ZStack {
                        RoundedRectangle(cornerRadius: 45)
                            .frame(width: 165, height: 65)
                            .foregroundStyle(LinearGradient(gradient: Gradient(colors: [Color.mint, Color.cyan]), startPoint: .top, endPoint: .bottom))
                        Text("Continue")
                            .foregroundStyle(.white)
                            .font(.title)
                            .fontWeight(.semibold)
                            .shadow(radius: 4)
                    }
                    .shadow(color: .mint, radius: 2, x: -2, y: -2)
                    .shadow(color: .cyan, radius: 2, x: 2, y: 2)
                }
                .padding(.all)
                .padding(.bottom, 20)
                .accessibilityAddTraits(.isButton)
                
            }
            .padding()
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(bgGradient)
        }
    }
}

extension View {
    func animate(using animation: Animation = .easeInOut(duration: 1), _ action: @escaping () -> Void) -> some View {
        onAppear {
            withAnimation(animation) {
                action()
            }
        }
    }
}
