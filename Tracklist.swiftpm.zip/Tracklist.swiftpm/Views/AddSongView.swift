import SwiftUI

struct AddSongView: View {
    @Environment(\.modelContext) var modelContext
    @Environment(\.dismiss) var dismiss
    
    @State private var title = ""
    @State private var artist = ""
    @State private var genre = ""
    @State private var review = ""
    @State private var rating = 3
    @State private var isCompleted = false
    
    @State private var showAlert: Bool = false
    @State private var alertTitle: String = ""
    
    let purpleCustom = Color(red: 0.20, green: 0.09, blue: 0.30, opacity: 1.00)
    let blueCustom = Color(red: 0.10, green: 0.14, blue: 0.28, opacity: 1.00)
    
    var body: some View {
        let bgGradient = LinearGradient(colors: [.clear, purpleCustom], startPoint: .topLeading, endPoint: .bottomTrailing)
        
        NavigationStack {
            ZStack {
                VStack {
                    Form {
                        Section {
                            TextField("Song title", text: $title)
                            TextField("Artist", text: $artist)
                            TextField("Genre", text: $genre)
                            Picker("Rating", selection: $rating) {
                                ForEach(0..<6) {
                                    Text(String($0))
                                }
                            }
                        }
                        
                        Section("What's your review?") {
                            TextField("Thoughts here...", text: $review, axis: .vertical)
                        }
                        
                        
                    }
                    ScrollView {
                        VStack(alignment: .leading) {
                            ZStack(alignment: .leading) {
                                RoundedRectangle(cornerRadius: 25.0)
                                    .frame(maxWidth: .infinity)
                                    .foregroundStyle(.ultraThinMaterial)
                                    .shadow(radius: 4)
                                
                                Text("Review Prompts to Get Started!")
                                    .font(.largeTitle)
                                    .fontWeight(.semibold)
                                    .padding()
                            }
                            .padding()
                            
                            ZStack(alignment: .leading) {
                                RoundedRectangle(cornerRadius: 25.0)
                                    .frame(maxWidth: .infinity)
                                    .foregroundStyle(.ultraThinMaterial)
                                    .shadow(radius: 4)
                                
                                VStack(alignment: .leading) {
                                    VStack(alignment: .leading) {
                                        Text("First Impressions")
                                            .font(.title)
                                            .fontWeight(.semibold)
                                            .padding(.vertical, 4)
                                        
                                        Text("How does the music make you feel by the first impression of it?")
                                            .font(.headline)
                                        
                                        Text("Does it meet your expectations?")
                                            .font(.headline)
                                    }
                                    .padding()
                                    
                                    VStack(alignment: .leading) {
                                        Text("Melody and Harmony")
                                            .font(.title)
                                            .fontWeight(.semibold)
                                            .padding(.vertical, 4)
                                        
                                        Text("Melody - catchy, complex or memorable?")
                                            .font(.headline)
                                        
                                        Text("Harmony - smooth, interesting or clashing?")
                                            .font(.headline)
                                    }
                                    .padding()
                                    
                                    VStack(alignment: .leading) {
                                        Text("Lyrics and Vocal")
                                            .font(.title)
                                            .fontWeight(.semibold)
                                            .padding(.vertical, 4)
                                        
                                        Text("Does it resonates with you, meaningful or well-written?")
                                            .font(.headline)
                                        
                                        Text("The way lyrics are delivered, impactful or skilled?")
                                            .font(.headline)
                                    }
                                    .padding()
                                    
                                    VStack(alignment: .leading) {
                                        Text("Production and Instrumentals") 
                                            .font(.title)
                                            .fontWeight(.semibold)
                                            .padding(.vertical, 4)
                                        
                                        Text("Did the productions enhances/distracted the song?")
                                            .font(.headline)
                                        
                                        Text("Did the instrumentals compliment each other?")
                                            .font(.headline)
                                    }
                                    .padding()
                                    
                                    VStack(alignment: .leading) {
                                        Text("Overall Thoughts") 
                                            .font(.title)
                                            .fontWeight(.semibold)
                                            .padding(.vertical, 4)
                                        
                                        Text("Wanna listen to it again?")
                                            .font(.headline)
                                        
                                        Text("Do you recommend this to others?")
                                            .font(.headline)
                                        
                                        Text("How would you rate this from 0 to 5 stars?")
                                            .font(.headline)
                                    }
                                    .padding()
                                }
                            }
                            .padding()
                        }
                    }
                    
                    
                    
                    
                    
                    HStack {
                        
                        Spacer()
                        
                        Button {
                            if textIsAppropriate() {
                                let newSong = Songs(name: title, artist: artist, genre: genre, review: review, rating: rating, isCompleted: isCompleted)
                                modelContext.insert(newSong)
                                dismiss()
                            }
                        } label: {
                            ZStack {
                                RoundedRectangle(cornerRadius: 45)
                                    .frame(width: 165, height: 65)
                                    .foregroundStyle(LinearGradient(gradient: Gradient(colors: [Color.mint, Color.cyan]), startPoint: .top, endPoint: .bottom))
                                Text("Save")
                                    .foregroundStyle(.white)
                                    .shadow(radius: 4)
                                    .font(.title)
                                    .fontWeight(.semibold)
                            }
                            .shadow(color: .mint, radius: 2, x: -2, y: -2)
                            .shadow(color: .cyan, radius: 2, x: 2, y: 2)
                        }
                        .padding()
                        .accessibilityAddTraits(.isButton)
                        
                        Spacer()
                    }
                    
                    Spacer()
                }
                
                
            }
            .toolbar {
                Button("Cancel") {
                    dismiss()
                }
                .accessibilityAddTraits(.isButton)
            }
            .alert(isPresented: $showAlert, content: getAlert)
            .scrollContentBackground(.hidden)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(bgGradient)
            .environment(\.colorScheme, .dark)
            .navigationTitle("Add Music")
        }
    }
    
    func textIsAppropriate() -> Bool {
        if title.count < 3 {
            alertTitle = "Your title has to be at least 3 characters long."
            showAlert = true
            return false
        } else if artist.count < 3 {
            alertTitle = "Your artist name has to be at least 3 characters long."
            showAlert = true
            return false
        } else if genre.count < 1 {
            alertTitle = "Your genre has to be at least 1 characters long."
            showAlert = true
            return false
        } else if review.count < 3 {
            alertTitle = "Your review has to be at least 3 characters long."
            showAlert = true
            return false
        }
        return true
    }
    
    func getAlert() -> Alert {
        return Alert(title: Text(alertTitle))
    }
}

#Preview {
    AddSongView()
        .modelContainer(for: Songs.self)
}
