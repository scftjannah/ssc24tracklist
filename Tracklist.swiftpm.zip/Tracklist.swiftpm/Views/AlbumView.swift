import SwiftUI
import SwiftData

struct AlbumView: View {
    @Environment(\.modelContext) var modelContext
    @Environment(\.colorScheme) var colorScheme
    @Query(sort: \Songs.name, animation: .smooth(duration: 0.6)) var songs: [Songs]
    
    @State private var showingDeleteAlert: Bool = false
    @State private var showingAddScreen = false
    @State private var showingNotifySheet = false
    @State private var showingOnboardingScreen = false
    @State private var shouldShowOnboarding = false
    
    let purpleCustom = Color(red: 0.20, green: 0.09, blue: 0.30, opacity: 1.00)
    let blueCustom = Color(red: 0.10, green: 0.14, blue: 0.28, opacity: 1.00)
    
    var body: some View {
        let bgGradient = LinearGradient(colors: [.clear, purpleCustom], startPoint: .topLeading, endPoint: .bottomTrailing)
        let listGradient = LinearGradient(gradient: Gradient(colors: [Color.indigo, purpleCustom]), startPoint: .top, endPoint: .bottom)
        
        NavigationStack {
            ZStack {
                
                if songs.isEmpty {
                    NoListView()
                } else {
                    ScrollView {
                        ForEach(songs, id: \.self) { song in
                            ZStack {
                                RoundedRectangle(cornerRadius: 25)
                                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                                    .foregroundStyle(listGradient)
                                
                                VStack(alignment: .leading) {
                                    
                                    HStack {
                                        
                                        VStack(alignment: .leading) {
                                            Text(song.name)
                                                .font(.title)
                                                .fontWeight(.semibold)
                                                .foregroundStyle(.white)
                                            
                                            HStack(alignment: .top) {
                                                Text(song.artist)
                                                    .font(.headline)
                                                    .foregroundStyle(.white)
                                                
                                                Divider()
                                                
                                                Text(String(song.rating))
                                                    .foregroundStyle(.white) + Text(Image(systemName: "star.fill"))
                                                    .foregroundStyle(.yellow)
                                                
                                                Divider()
                                                
                                                Text(song.genre)
                                                    .foregroundColor(.white)
                                            }
                                        }
                                        .padding()
                                        
                                        Spacer()
                                        
                                        VStack(alignment: .trailing) {
                                            HStack {
                                                Text("Listened:")
                                                    .font(.title2)
                                                    .fontWeight(.semibold)
                                                
                                                Image(systemName: song.isCompleted ? "checkmark.circle" : "checkmark.circle.fill")
                                                    .resizable()
                                                    .frame(width: 50, height: 50)
                                                    .foregroundStyle(song.isCompleted ? .red : .green)
                                                    .shadow(color: song.isCompleted ? .red : .green, radius: 2)
                                                    .onTapGesture {
                                                        song.isCompleted.toggle()
                                                    }
                                                    .padding()
                                                    .accessibilityLabel(song.isCompleted ? "Song not listened" : "Song Listened")
                                            }
                                        }
                                    }
                                    .padding()
                                    
                                    HStack {
                                        Text("Review:")
                                            .font(.title)
                                            .fontWeight(.semibold)
                                            .foregroundStyle(.white)
                                        
                                        Spacer()
                                        
                                        Button {
                                            showingDeleteAlert = true
                                        } label: {
                                            Image(systemName: "trash.fill")
                                                .resizable()
                                                .scaledToFit()
                                                .frame(width: 25, height: 25)
                                                .foregroundStyle(.red)
                                                .accessibilityLabel("Delete song list \(song.name)")
                                        }
                                        .alert("Delete Item", isPresented: $showingDeleteAlert) {
                                            Button("Delete", role: .destructive) { 
                                                modelContext.delete(song) }
                                            Button("Cancel", role: .cancel) {} 
                                        } message: {
                                            Text("Are you sure you want to delete the item?")
                                        }
                                    }
                                    .padding(.horizontal, 30)
                                    
                                    ZStack {
                                        RoundedRectangle(cornerRadius: 25)
                                            .frame(maxWidth: .infinity, maxHeight: .infinity)
                                            .foregroundStyle(.thinMaterial)
                                        
                                        Text(song.review)
                                            .padding()
                                            .lineLimit(6)
                                    }
                                    .padding()
                                    
                                    Spacer()
                                }
                            }
                            .shadow(radius: 4)
                            .padding()
                        }
                    }
                }
                
                VStack {
                    Spacer()
                    
                    HStack {
                        Spacer()
                        
                        Button {
                            showingAddScreen = true
                        } label: {
                            ZStack {
                                RoundedRectangle(cornerRadius: 45)
                                    .frame(width: 75, height: 75)
                                    .foregroundStyle(LinearGradient(gradient: Gradient(colors: [Color.mint, Color.cyan]), startPoint: .top, endPoint: .bottom))
                                Image(systemName: "plus")
                                    .resizable()
                                    .frame(width: 30, height: 30)
                                    .foregroundStyle(.white)
                                    .shadow(radius: 4)
                                    .accessibilityRemoveTraits(.isImage)
                            }
                            .shadow(color: .mint, radius: 2, x: -2, y: -2)
                            .shadow(color: .cyan, radius: 2, x: 2, y: 2)
                        }
                        .padding()
                        .accessibilityLabel("Add Song")
                    } 
                }
            }
            .sheet(isPresented: $showingOnboardingScreen) {
                OnboardingView(shouldShowOnboarding: $shouldShowOnboarding)
            }
            .sheet(isPresented: $showingAddScreen) {
                AddSongView()
            }
            .scrollContentBackground(.hidden)                
            .navigationTitle("Songs")
            .navigationBarTitleDisplayMode(.large)
            .background(bgGradient)
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .toolbar(content: {
                Button {
                    showingOnboardingScreen = true
                } label: {
                    Image(systemName: "book.pages")
                    Text("Onboarding")
                }
            })
        }
        .environment(\.colorScheme, .dark)
    }
    
    
    func delete(_ indexSet: IndexSet) {
        for i in indexSet {
            let song = songs[i]
            modelContext.delete(song)
        }
    }
    
}

#Preview {
    AlbumView()
        .modelContainer(for: Songs.self)
}
