import SwiftUI
import SwiftData
import Charts

struct ChartView: View {
    @Environment(\.dismiss) var dismiss
    @Query var songs: [Songs]
    
    let purpleCustom = Color(red: 0.20, green: 0.09, blue: 0.30, opacity: 1.00)
    
    var body: some View {
        
        let bgGradient = LinearGradient(colors: [.clear, purpleCustom], startPoint: .topLeading, endPoint: .bottomTrailing)
        
        NavigationStack {
            ZStack {
                if songs.isEmpty {
                    ContentUnavailableView {
                        Label("No List Available", systemImage: "list.bullet.rectangle")
                            .accessibilityRemoveTraits(.isImage)
                            .accessibilityAddTraits(.isHeader)
                    } description: {
                        Text("There's no list to make a chart by, start by adding a list on the 'Songs' tab!")
                    } 
                } else {
                    TabView {
                        ZStack {
                            RoundedRectangle(cornerRadius: 25.0)
                                .frame(maxWidth: .infinity, maxHeight: .infinity)
                                .shadow(radius: 4)
                                .foregroundStyle(.thinMaterial)
                            
                            VStack(alignment: .leading) {
                                Text("Artist Listed:")
                                    .font(.title)
                                    .fontWeight(.semibold)
                                    .padding()
                                
                                Chart {
                                    ForEach(songs) { song in
                                        BarMark(x: PlottableValue.value("Artist", song.artist), y: .value("Frequency", songs.count / songs.count))
                                    }
                                }
                                .chartXScale(range: .plotDimension(padding: 35))
                                .chartYScale(range: .plotDimension(padding: 45))
                                .padding()
                                .shadow(radius: 4)
                            }
                            .padding()
                        }
                        .padding()
                        
                        ZStack {
                            RoundedRectangle(cornerRadius: 25.0)
                                .frame(maxWidth: .infinity, maxHeight: .infinity)
                                .shadow(radius: 4)
                                .foregroundStyle(.thinMaterial)
                            
                            VStack(alignment: .leading) {
                                Text("Rating Listed:")
                                    .font(.title)
                                    .fontWeight(.semibold)
                                    .padding()
                                
                                Chart {
                                    ForEach(songs) { song in
                                        BarMark(x: PlottableValue.value("Rating", String(song.rating)), y: .value("Frequency", songs.count / songs.count))
                                    }
                                }
                                .chartXScale(range: .plotDimension(padding: 35))
                                .chartYScale(range: .plotDimension(padding: 75))
                                .padding()
                                .shadow(radius: 4)
                            }
                            .padding()
                        }
                        .padding()
                        
                        ZStack {
                            RoundedRectangle(cornerRadius: 25.0)
                                .frame(maxWidth: .infinity, maxHeight: .infinity)
                                .shadow(radius: 4)
                                .foregroundStyle(.thinMaterial)
                            
                            VStack(alignment: .leading) {
                                Text("Genre Listed:")
                                    .font(.title)
                                    .fontWeight(.semibold)
                                    .padding()
                                
                                Chart {
                                    ForEach(songs) { song in
                                        BarMark(x: PlottableValue.value("Genre", song.genre), y: .value("Frequency", songs.count / songs.count ))
                                    }
                                }
                                .chartXScale(range: .plotDimension(padding: 35))
                                .chartYScale(range: .plotDimension(padding: 60))
                                .padding()
                                .shadow(radius: 4)
                            }
                            .padding()
                        }
                        .padding()
                        
                        
                    }
                    .tabViewStyle(.page)
                    .indexViewStyle(.page(backgroundDisplayMode: .automatic))
                }
            }
            .toolbar(content: {
                ShareLink(item: String("I just use my Tracklist app, and I think it's very cool, what do you think?"), label: {
                    Image(systemName: "square.and.arrow.up")
                    Text("Share App")
                })
            })
            .navigationTitle("Charts")
            .background(bgGradient)
        }
    }
}

#Preview {
    ChartView()
}
