import SwiftUI

struct NoListView: View {
    var body: some View {
        
        ContentUnavailableView {
            Label("No Song List Yet...", systemImage: "music.note.list")
                .accessibilityRemoveTraits(.isImage)
                .accessibilityAddTraits(.isHeader)
                .accessibilityLabel("No song list yet")
        } description: {
            Text("What are you waiting for? Add one by the plus button on the corner of your screen!")
        }
        
        VStack {
            Spacer()
            
            HStack {
                Spacer()
                
                Spacer()
                
                Image("listEmptySketch")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 500, height: 250)
                
            }
        }
    }
}

#Preview {
    NoListView()
}
